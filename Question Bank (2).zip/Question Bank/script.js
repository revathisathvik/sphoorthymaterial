document.addEventListener('DOMContentLoaded', function() {
    console.log("Engineering Subjects Portal is ready!");
});
